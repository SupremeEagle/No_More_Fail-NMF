----NMF----
No More Fail      by TheSupremeEagle
 v0.6.7 Bêta
Made for Osu!


Welcome to NMF [No More Fail], an help to improve for new player, or even PRO player !
With this program based on the map difficulty, your skill and the performance of the best Osu! players
You can easily, with a map, get a calculation of how many fails you'll have not to reach on the map chosen
(Of course, sometimes it can be too difficult. It's not a problem, take your time to reach your goal :1 )

Also, take the time to save around 10 to 20 maps in NMF to use the command [Train]
The program will give you a map to train on (with mods and fails result)
It will challenge you by your profil and by the map saved
More maps you have saved, more various and challenging result you will get


Bonne chance ! :3


At first launch, the program will close several time to create saves and data
It's not a bug, don't worry
This program is in developpement, if you have any problem, say it to me by my discord (SupremeEagle#1551)
Or from Osu! > My Username: TheSupremeEagle / My (actuel) Ranked: 35 000

Warning: Removing the file [profil] can repair some issues, but also reset your NMF profil and
         removing the file [maps] can repair some issues about the maps, but also reset all your maps saved in NMF
	 If your profil is wrong, reset it
    	 If the informations of the maps looks weird, say it to me and I will repair that without removing them
	 Finally, removing the file [data] can repair issues without removing your profil or the maps saved in NMF
	 try this solution at first
	 That can be weird but using the program in full screen can repair some problem
	 So i recommend to use it in Full Screen
	 And pressing [Enter] before typing a command, or typing a wrong command, can make the program crash
	 Make sure to write words correctly :)

ps. Thx u to try it and use it even if Tillerino is way better
    i'v just want to try something different like proposing maps at your level and proposing a fails calculation
    i'm terribly new in coding, but have a good knowledge of math and Osu!... so there it is
    hope you enjoy, lov u <3



























MAJ Majeur:
ajt Balisation > code
Ajt Intro str
Réastabilisation rslt
*if MPFinal > MPNative = MPNative - 1*
Ajt input
*"Commandes naviguer"
		Start/start
		 Help/help
		  End/end*
Réastabilisation rslt
*Multiplicateur d'MA 1/0.3-0.3
		      2/0.8-0.7
		       3/1-1.1
		        4/1.2/1.55
		         5/1.7-1.9*
Ajt txt
*input txt MBpm/"Moyenne"*
Ajt fin
*input End/*
Ajt input Profil
	Ajt x2 input /Profil
		> reset
		 > menu
Ajt input Maps
	Ajt x5+ input /Start
		> new
		 > library
		  > last
Réastabilisation rslt
*ProfilDiff ~Pro~ /Multiplicateur [0.4 > 0.3]
Ajt mods Calculation
*[Titre...] + Mods*
		> HD HR DT FL NF RX HT
Ajt Lisibilité + Corrections GRM VOC
*input() > print"-------"*
*Txt /-intro /-expl*
Réparation input(maps)
Ajt input Remove
	> temove all
	 > thoose one
	  > title
Ajt input Train
*Start/[new] part* + *Mods part*
		= new file calculation "data"
Réastabilisation Rslt
*Train/mode PropFinal = (3) = [1.2.1 > 1.0.1]*
